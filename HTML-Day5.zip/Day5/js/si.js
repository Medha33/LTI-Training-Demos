function interest(pa, ri, ny) {
    principalAmount = parseFloat(pa.value);
    rateOfInterest = parseFloat(ri.value);
    noOfYears = parseFloat(ny.value);

    si = (principalAmount * rateOfInterest * noOfYears) / 100;

    document.getElementById("si").innerHTML = 'Simple Interest: ' + si;
}
function clearMsg() {
    document.getElementById("si").innerHTML = "";
}
function verifyUser() {
    if (localStorage.getItem("username") == null) {
        window.open("../index.html");
    }
}
function logOut(){
    if(localStorage.username){
        //removing individually by keyname
        localStorage.removeItem("username");
        //removing all keys with clear()--optional
        localStorage.clear();
        window.open("../index.html");
    }
}
