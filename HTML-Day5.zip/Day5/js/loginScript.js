//loginScript.js - external javascript

function verifyLogin(loginForm) {
    if (loginForm.checkValidity()) {
        var username = loginForm.txtUn.value;
        var password = loginForm.txtPwd.value;
        if (username === "admin@gmail.com" && password === "123456") {
            alert('Login Successful!');
            //sessionStorage.setItem("username",username);
            localStorage.setItem("username",username);
            window.open("../pages/si.html", "_blank");
        }
        else
            alert('Invalid username or password');
    }
}